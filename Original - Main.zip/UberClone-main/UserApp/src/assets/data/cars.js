export default [
  {
    id: '0',
    type: 'UberX',
    latitude: 28.450627,
    longitude: -16.263045,
    heading: 47,
  },
  {
    id: '1',
    type: 'Comfort',
    latitude: 28.456312,
    longitude: -16.252929,
    heading: 190,
  },
  {
    id: '2',
    type: 'UberXL',
    latitude: 28.456208,
    longitude: -16.259098,
    heading: 99,
  },
  {
    id: '3',
    type: 'Comfort',
    latitude: 28.454812,
    longitude:-16.258658,
    heading: 120,
  },
];
